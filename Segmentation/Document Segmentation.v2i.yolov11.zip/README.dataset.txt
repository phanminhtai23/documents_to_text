# Document Segmentation > 2024-07-10 3:04am
https://universe.roboflow.com/maulvi-zm/document-segmentation-j6olp

Provided by a Roboflow user
License: CC BY 4.0

